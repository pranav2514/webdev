function parseAdjList(text) {
    const graph = {};
    const entries = text.split(";");
    for (let entry of entries) {
        if (!entry.includes(":")) continue;
        const [node, neighbors] = entry.split(":");
        graph[parseInt(node)] = neighbors.split(",").map(n => parseInt(n.trim()));
    }
    return graph;
}

function bfs() {
    const graph = parseAdjList(document.getElementById("adjList").value);
    const start = parseInt(document.getElementById("startNode").value);
    let visited = new Set();
    let queue = [start];
    let order = [];
    while (queue.length > 0) {
        let node = queue.shift();
        if (!visited.has(node)) {
            visited.add(node);
            order.push(node);
            queue.push(...(graph[node] || []).filter(n => !visited.has(n)));
        }
    }
    document.getElementById("output").innerText = "BFS Order: " + order.join(", ");
}

function dfs() {
    const graph = parseAdjList(document.getElementById("adjList").value);
    const start = parseInt(document.getElementById("startNode").value);
    let visited = new Set();
    let stack = [start];
    let order = [];
    while (stack.length > 0) {
        let node = stack.pop();
        if (!visited.has(node)) {
            visited.add(node);
            order.push(node);
            stack.push(...(graph[node] || []).filter(n => !visited.has(n)).reverse());
        }
    }
    document.getElementById("output").innerText = "DFS Order: " + order.join(", ");
}
