import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Catalogue() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/items').then((res) => {
      setItems(res.data);
    });
  }, []);

  return (
    <div>
      <h2>Grocery Catalogue</h2>
      {items.map((item) => (
        <div key={item.id}>
          <h3>{item.name}</h3>
          <p>Category: {item.category}</p>
          <p>Price: ${item.price}</p>
        </div>
      ))}
    </div>
  );
}
