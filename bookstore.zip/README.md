# Bookstore Project
Instructions to run the project on Mac.