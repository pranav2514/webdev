class TreeNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}

class BST {
  constructor() {
    this.root = null;
  }

  insert(value) {
    const newNode = new TreeNode(value);
    if (!this.root) {
      this.root = newNode;
      return;
    }
    let current = this.root;
    while (true) {
      if (value < current.value) {
        if (!current.left) {
          current.left = newNode;
          return;
        }
        current = current.left;
      } else {
        if (!current.right) {
          current.right = newNode;
          return;
        }
        current = current.right;
      }
    }
  }

  inOrder(node, result = []) {
    if (node) {
      this.inOrder(node.left, result);
      result.push(node.value);
      this.inOrder(node.right, result);
    }
    return result;
  }

  search(node, value) {
    if (!node) return false;
    if (node.value === value) return true;
    if (value < node.value) return this.search(node.left, value);
    return this.search(node.right, value);
  }
}

const bst = new BST();

function insertValue() {
  const value = parseInt(document.getElementById("inputValue").value);
  if (!isNaN(value)) {
    bst.insert(value);
    document.getElementById("inputValue").value = '';
  }
}

function sortTree() {
  const sorted = bst.inOrder(bst.root);
  document.getElementById("sortedOutput").textContent = sorted.join(", ");
}

function searchTree() {
  const value = parseInt(document.getElementById("inputValue").value);
  const found = bst.search(bst.root, value);
  document.getElementById("searchResult").textContent = found ? "Found" : "Not Found";
}
