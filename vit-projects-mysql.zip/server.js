const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // Set your MySQL password here
  database: 'vit_projects'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

app.get('/api/course', (req, res) => {
  db.query('SELECT * FROM course_projects', (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

app.post('/api/course', (req, res) => {
  const { title, description } = req.body;
  db.query('INSERT INTO course_projects (title, description) VALUES (?, ?)', [title, description], err => {
    if (err) throw err;
    res.sendStatus(200);
  });
});

app.get('/api/edi', (req, res) => {
  db.query('SELECT * FROM edi_projects', (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

app.post('/api/edi', (req, res) => {
  const { title, description } = req.body;
  db.query('INSERT INTO edi_projects (title, description) VALUES (?, ?)', [title, description], err => {
    if (err) throw err;
    res.sendStatus(200);
  });
});

app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
