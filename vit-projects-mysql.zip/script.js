$(document).ready(function () {
  loadProjects();

  $('#courseForm').submit(function (e) {
    e.preventDefault();
    const title = $('#courseTitle').val();
    const desc = $('#courseDesc').val();
    $.post('/api/course', { title, description: desc }, loadProjects);
    this.reset();
  });

  $('#ediForm').submit(function (e) {
    e.preventDefault();
    const title = $('#ediTitle').val();
    const desc = $('#ediDesc').val();
    $.post('/api/edi', { title, description: desc }, loadProjects);
    this.reset();
  });

  function loadProjects() {
    $.get('/api/course', function (data) {
      $('#courseList').empty();
      data.forEach(p => $('#courseList').append(`<li class="list-group-item"><strong>${p.title}</strong><br>${p.description}</li>`));
    });
    $.get('/api/edi', function (data) {
      $('#ediList').empty();
      data.forEach(p => $('#ediList').append(`<li class="list-group-item"><strong>${p.title}</strong><br>${p.description}</li>`));
    });
  }
});
