CREATE DATABASE IF NOT EXISTS vit_projects;
USE vit_projects;

CREATE TABLE IF NOT EXISTS course_projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255),
  description TEXT
);

CREATE TABLE IF NOT EXISTS edi_projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255),
  description TEXT
);
