package com.vit.result.service;

import com.vit.result.model.Marks;
import com.vit.result.model.Student;
import com.vit.result.repository.EseRepository;
import com.vit.result.repository.MseRepository;
import com.vit.result.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ResultService {
    private final StudentRepository studentRepo;
    private final MseRepository mseRepo;
    private final EseRepository eseRepo;

    public ResultService(StudentRepository s, MseRepository m, EseRepository e) {
        this.studentRepo = s;
        this.mseRepo = m;
        this.eseRepo = e;
    }

    public Map<String, Object> getResult(int studentId) {
        Student student = studentRepo.findById(studentId).orElse(null);
        List<Marks> marks = new ArrayList<>();
        if (student != null) {
            List<String> subjects = Arrays.asList("Maths", "Physics", "Chemistry", "English");
            for (String sub : subjects) {
                int mse = mseRepo.findByStudentIdAndSubject(studentId, sub).getMarks();
                int ese = eseRepo.findByStudentIdAndSubject(studentId, sub).getMarks();
                marks.add(new Marks(sub, mse, ese));
            }
        }
        Map<String, Object> result = new HashMap<>();
        result.put("name", student.getName());
        result.put("marks", marks);
        return result;
    }
}
