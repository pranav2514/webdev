package com.vit.result.repository;

import com.vit.result.model.Ese;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EseRepository extends JpaRepository<Ese, Integer> {
    Ese findByStudentIdAndSubject(int studentId, String subject);
}
