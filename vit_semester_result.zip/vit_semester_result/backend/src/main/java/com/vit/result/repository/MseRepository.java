package com.vit.result.repository;

import com.vit.result.model.Mse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MseRepository extends JpaRepository<Mse, Integer> {
    Mse findByStudentIdAndSubject(int studentId, String subject);
}
