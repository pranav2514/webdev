package com.vit.result.controller;

import com.vit.result.service.ResultService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/result")
@CrossOrigin(origins = "*")
public class ResultController {
    private final ResultService resultService;

    public ResultController(ResultService resultService) {
        this.resultService = resultService;
    }

    @GetMapping("/{studentId}")
    public Map<String, Object> getResult(@PathVariable int studentId) {
        return resultService.getResult(studentId);
    }
}
