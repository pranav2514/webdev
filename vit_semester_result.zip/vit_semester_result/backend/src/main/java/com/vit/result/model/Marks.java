package com.vit.result.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data @AllArgsConstructor
public class Marks {
    private String subject;
    private int mse;
    private int ese;
}
