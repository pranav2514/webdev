import React, { useState } from "react";
import axios from "axios";

function App() {
  const [studentId, setStudentId] = useState("");
  const [result, setResult] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.get(`http://localhost:8080/result/${studentId}`).then((res) => {
      setResult(res.data);
    });
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h2>VIT Semester Result</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
          placeholder="Enter Student ID"
        />
        <button type="submit">Get Result</button>
      </form>
      {result && (
        <div style={{ marginTop: "20px" }}>
          <h3>Student: {result.name}</h3>
          <table border="1" cellPadding="8">
            <thead>
              <tr>
                <th>Subject</th>
                <th>MSE</th>
                <th>ESE</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {result.marks.map((s, i) => (
                <tr key={i}>
                  <td>{s.subject}</td>
                  <td>{s.mse}</td>
                  <td>{s.ese}</td>
                  <td>{(s.mse * 0.3 + s.ese * 0.7).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default App;
