
CREATE DATABASE IF NOT EXISTS electricity;
USE electricity;

CREATE TABLE IF NOT EXISTS consumer (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    address TEXT
);

CREATE TABLE IF NOT EXISTS billing (
    id INT AUTO_INCREMENT PRIMARY KEY,
    consumer_id INT,
    units INT,
    amount DECIMAL(10,2),
    date DATE,
    FOREIGN KEY (consumer_id) REFERENCES consumer(id)
);
