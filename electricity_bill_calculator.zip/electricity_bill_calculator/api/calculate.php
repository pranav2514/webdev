<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "electricity";

$conn = new mysqli($host, $user, $pass, $db);

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $consumer_id = $_POST['consumer_id'];
    $units = $_POST['units'];

    function calculateBill($units) {
        if ($units <= 50) return $units * 3.50;
        elseif ($units <= 150) return 50 * 3.50 + ($units - 50) * 4.00;
        elseif ($units <= 250) return 50 * 3.50 + 100 * 4.00 + ($units - 150) * 5.20;
        else return 50 * 3.50 + 100 * 4.00 + 100 * 5.20 + ($units - 250) * 6.50;
    }

    $amount = calculateBill($units);
    $date = date("Y-m-d");

    $stmt = $conn->prepare("INSERT INTO billing (consumer_id, units, amount, date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iids", $consumer_id, $units, $amount, $date);
    $stmt->execute();

    echo json_encode(["message" => "Total bill for $units units: ₹" . number_format($amount, 2)]);
}
?>
