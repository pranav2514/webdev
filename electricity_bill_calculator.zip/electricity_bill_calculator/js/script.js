$(document).ready(function() {
    $('#billForm').submit(function(e) {
        e.preventDefault();
        $.post('api/calculate.php', {
            consumer_id: $('#consumer_id').val(),
            units: $('#units').val()
        }, function(data) {
            $('#result').html('<div class="alert alert-info">' + data.message + '</div>');
        }, 'json');
    });
});
